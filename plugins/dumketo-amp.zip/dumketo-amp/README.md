This custom AMP theme built for AMPforWP plugin, This Theme is developed by <a href="http://dumketo.github.io/Resume/">Hasan Ahmed Jobayer</a>


