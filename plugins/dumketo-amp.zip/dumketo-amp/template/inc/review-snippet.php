<?php
/*
* Review Snippet
* Developer: Hasan Ahmed Jobayer
*/

global $redux_builder_amp;
if ( $redux_builder_amp['rating_switch'] == 1 ) :
    function review_snippet(){
        global $redux_builder_amp;
    ?>
        <script type="application/ld+json">
            {
            "@context": "http://schema.org",
            "@type": "Product",
            "name": <?php echo $redux_builder_amp['damp_find_place'] ?>,
            <?php $url = 'https://maps.googleapis.com/maps/api/place/textsearch/json?query='. urlencode($redux_builder_amp['damp_find_place']).'&key='. $redux_builder_amp['damp_google_api_places_key'];
                $json = file_get_contents( $url );
                $data = json_decode( $json, true );
            ?>
                "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "<?php echo $data["results"][0]["rating"] ?>",
                "reviewCount": "<?php echo $redux_builder_amp['damp_total_reviews'] ?>"
                }
            }
        </script>
    <?php
    }
    add_action('wp_head', 'review_snippet');
endif;
?>
