<?php
/*
Name: Function
Developer: Hasan Ahmed Jobayer
*/

//Social Icons
add_amp_theme_support('AMP-social-icons');