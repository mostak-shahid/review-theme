<?php
/*
* Related Post Section
* Developer: Hasan Ahmed Jobayer
*/

	global $post,  $redux_builder_amp;
	do_action('ampforwp_above_related_post',$this); //Above Related Posts
	$string_number_of_related_posts = $redux_builder_amp['ampforwp-number-of-related-posts'];
    $int_number_of_related_posts = round(abs(floatval($string_number_of_related_posts)));

	// declaring this variable here to prevent debug errors
	$args = null;
	$orderby = 'ID';
	// Check for the order of related posts
	if( isset( $redux_builder_amp['ampforwp-single-order-of-related-posts'] ) && $redux_builder_amp['ampforwp-single-order-of-related-posts'] ){
		$orderby = 'rand';
	}
    $args = array(
        'posts_per_page'=> $int_number_of_related_posts,
        'order' => 'DESC',
        'orderby' => $orderby,
        'post_type' => 'post',
        'post__not_in' => array( $post->ID )
    );
	$my_query = new wp_query( $args );
		if( $my_query->have_posts() ) { ?>
			<div class="amp-wp-content relatedpost">
			    <div class="related_posts">
					<ol class="clearfix">
						<?php
					    while( $my_query->have_posts() ) {
						    $my_query->the_post();
							$related_post_permalink = ampforwp_url_controller( get_permalink() );?>
							<li class="<?php if ( ampforwp_has_post_thumbnail() ) { echo'has_related_thumbnail'; } else { echo 'no_related_thumbnail'; } ?>">
                                <a href="<?php echo esc_url( $related_post_permalink ); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
							<?php if ( ampforwp_has_post_thumbnail() ) {
							$thumb_url = ampforwp_get_post_thumbnail();
								if($thumb_url){ ?>
					            	<amp-img src="<?php echo esc_url( $thumb_url ); ?>" width="150" height="150" layout="responsive"></amp-img>
									<?php }
								}?>
                        	  	</a>
					                <div class="related_link">
					                    <a href="<?php echo esc_url( $related_post_permalink ); ?>"><?php the_title(); ?></a>
					                    <?php if(has_excerpt()){
											$content = get_the_excerpt();
										}else{
											$content = get_the_content();
										} ?>
					                    <p><?php echo wp_trim_words( strip_shortcodes($content) , '15' ); ?></p>
					                </div>
				            </li>
					<?php } ?>
					</ol>
			    </div>
			</div> <?php
			wp_reset_postdata();
	} ?>
<?php do_action('ampforwp_below_related_post',$this);
